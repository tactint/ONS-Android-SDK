package com.ons.android;

import android.app.Activity;

public class TestExcludedActivity extends Activity {}
