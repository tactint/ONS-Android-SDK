package com.ons.android.messaging.css;

public interface ImportFileProvider {
    String getContent(String importName);
}
