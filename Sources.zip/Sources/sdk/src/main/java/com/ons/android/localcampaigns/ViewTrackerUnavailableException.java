package com.ons.android.localcampaigns;

public class ViewTrackerUnavailableException extends Exception {

    public ViewTrackerUnavailableException() {}
}
