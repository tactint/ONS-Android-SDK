package com.ons.android;

import com.ons.android.annotation.PublicSDK;

/**
 * Represents an action source.
 */
@PublicSDK
public interface UserActionSource {}
