package com.ons.android.debug;

public interface OnMenuSelectedListener {
    void onMenuSelected(int menu);

    void onCampaignMenuSelected(String campaignToken);
}
