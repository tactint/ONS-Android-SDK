package com.ons.android.user;

public class UserDatabaseException extends Exception {

    public UserDatabaseException(String detailMessage) {
        super(detailMessage);
    }
}
